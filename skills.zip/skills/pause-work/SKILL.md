---
name: pause-work
description: Stop everything Ninja does on its own — the orchestrator working through its issue queue, and every scheduled job — or start it again. Use it whenever the user wants Ninja to stop acting by itself: direct requests ("stop", "pause", "stop working", "shut down", "stop the service", "stand down", "hold off", "take a break"), and indirect ones too — being told there is too much activity, that updates are no longer wanted, to be quiet for a while, or being asked why it is still working when they thought it had stopped. Use it again when they ask to resume, continue, unpause, or start working in the background again. The subject is Ninja's own activity as a whole. When the thing to stop is a specific object — a browser, a script, a download, one scheduled job, one task, a tool — that is not this skill.
---

# Pausing Ninja's background work

One command does all of it. Run it, then tell the user what happened.

```bash
python tools/pause.py pause      # stop the orchestrator and every enabled cron job
python tools/pause.py resume     # start them again
python tools/pause.py status     # what is off right now
```

`pause` turns the orchestrator off, stops the run that is already in flight, and
disables every cron job that was enabled — recording which ones, so `resume`
restores exactly those and leaves alone any the user had switched off themselves.

## What it does not stop

Say this plainly rather than letting the user assume otherwise:

- **You keep listening.** The user can still talk to you and you still answer.
  That is how they resume — no dashboard needed.
- **The sandbox keeps running, and it keeps costing.** Pausing the work does not
  stop the machine. Only the Pause control in the main UI does that.

## What to tell the user

`pause` prints a `main UI link:` line, already built for this environment. Use
that link exactly as printed — never type the host yourself.

Send this message as written, changing only the number of jobs and the link:

> ⏸️ Stopped — the orchestrator is off and N scheduled jobs are paused.
>
> I'm still here: talk to me any time, and say **"Resume"** when you want me
> working in the background again.
>
> The machine I run on is still up, so it still costs a little. To stop that
> too, select your project in the main UI and press **Pause**: <link>

Do not reword it, shorten it, or add anything.

If the user has been speaking another language, translate it — translate only,
keeping the three paragraphs and their order. Leave these four untranslated,
exactly as written:

- the ⏸️ emoji
- **"Resume"** — that literal word works whatever language they type in
- **Pause** — it is the label printed on the button they have to find
- the link

If the command says the in-flight run could not be stopped, change the first
line to say the orchestrator is off but the current run may finish, and leave
the rest as it is.

## Resuming

Only resume when the user actually asks for it. A question like "are you
stopped?" is not a request to start again — answer it and stay paused.
